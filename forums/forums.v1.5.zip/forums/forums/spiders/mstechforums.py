from scrapy import Spider, Request
from forums.items import ForumsItem
import re

# concurrent page-crawling
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

#class MstechforumsSpider(CrawlSpider): # Concurrent crawls
class MstechforumsSpider(Spider):       # Single crawl
    name = 'mstechforums'
    allowed_domains = ['social.technet.microsoft.com']
    #allowed_urls = ['https://social.technet.microsoft.com/']
    start_urls = ['https://social.technet.microsoft.com/Forums/en-us/home?sort=lastpostdesc&brandIgnore=true&page=1']
    print("{}\nStart URLs = {}".format('*'*50,start_urls))

    custoem_settings = { 'LOG_LEVEL': 'ERROR'}

    # concurrent crawls
    rules = [
        # test run with just crawling a few pages concurrently
    #    Rule(LinkExtractor(allow=('page=[2-10]$')), callback='parse_list', follow=True)
        Rule(LinkExtractor(allow=('page=\d$')), callback='parse_main', follow=True)
    ]

#    def parse_main(self, response):    # Concurrent crawls
    def parse(self, response):          # Single crawl

        self.log('\n\n{}\n\t\tSCRAPING STARTED\n{}\n'.format('-'*50,'-'*50))

        startThread, threadPerPage, totalThreads = \
            map(lambda x: int(x), re.findall('\d+',response.css('.itemSpan::text').extract_first()))
        
        totalPages = int(totalThreads)//int(threadPerPage) + 1

        print('Total Threads = {}\nThreads per Page = {}\nTotal Pages = {}'.format(totalThreads, threadPerPage, totalPages))
        #-------------------------------------------------------------------
        # After the coding is done, while testing at the boundary it turned out
        # the the site will display 10,000 threads or 500 pages at most. And on
        # page 500, it will still show the 'Next >' at the bottom and clickable.
        # Nevertheless, upon accessing page 501 and beyond, it results with the 
        # error: 'The search service is down. Please link directly to threads 
        # and come back later.' Essentially, the site will presnet 500 pages
        # and not further. Hence, here the last page is here hard-coded to 
        totalPages = 500
        print("Reset 'Total Pages' to {} which is the most pages the site allows.".format(totalPages))
        #-------------------------------------------------------------------
        
        target_urls = [
            'https://social.technet.microsoft.com/Forums/en-us/home?sort=lastpostdesc&brandIgnore=true&page={}'\
            .format(x) for x in range(1,totalPages+1)  
            ]

        scrapedPages = 0
        for url in target_urls[:5]: # For test run and scraping just a few pages
        # for url in target_urls:   # For production run to scrap the whole site

            nextClick = response.css('#threadPager_Next::text').extract_first()
            # if not nextClick: break  # no more page to scrap
                map(scrapIt(url))
            self.log('Yielding {}\n'.format(url))
            yield Request(url=url, callback=self.parse_the_page)

        self.log('\n{}\n\t\tSCRAPING ENDED\n{}\n\n'.format('-'*50,'-'*50))
        
    def parse_the_page(self, response):

        #threadsForThisPage = response.css('.detailscontainer > h3')
        # when needed, if nextClick: here

        threadFilter = re.sub('\s', '', \
            (re.sub(r'\r\n','',response.css('.selectedOption::text')[0].extract())))
        sortBy = re.sub('\s', '', \
            (re.sub(r'\r\n','',response.css('.selectedOption::text')[1].extract())))

        forumsItem = ForumsItem()

        forumsItem = {
            "votes": int((re.findall('\d+', response.css('div.votes div::text')[0].extract()))[0]),
            "threadState": response.css('.metrics.smallgreytext > span.statefilter > a::text')[0].extract(),
            "replyCount": int((re.findall('\d+', response.css('.replycount::text')[0].extract()))[0]),
            "viewCount": int((re.findall('\d+', response.css('.viewcount::text')[0].extract()))[0]),

            "threadTitle": response.css('.detailscontainer > h3 >a::text')[0].extract(),
            "threadTitleLink": response.css('.detailscontainer > h3 >a::attr(href)').extract_first(),
            "threadSummary": response.css('.threadSummary::text')[0].extract(),

            "createdByName": re.sub(r"\ \-\ $", '', response.css('.lastpost > a > span::text')[0].extract()),
            "createdByLink": response.css('.lastpost a:nth-child(2)::attr(href)')[1].extract(),
            "createdByTime": response.css('.lastpost span:nth-child(3)::text')[0].extract(),

            "lastReplyName": re.sub(r"\ \-\ $", '', response.css('.lastpost > a > span::text')[1].extract()),
            "lastReplyLink": response.css('.lastpost > a:nth-child(2)::attr(href)')[1].extract(),
            "lastReplyTime": response.css('.lastpost span:nth-child(3)::text')[1].extract(),
        }

        return forumsItem 
